import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { BrowserRouter, createBrowserRouter, RouterProvider } from 'react-router-dom';
import NotFound from './routes/NotFound.js';
import { Provider } from 'react-redux';
import store from './store.js';
import Profile from './routes/Profile.js';
import Account from './routes/Account.js';
import Career from './routes/Career.js';
import Talent from './routes/Talents.js';
import Bookmarks from './routes/Bookmarks.js';
import Contract from './routes/Contract.js';
import { GoogleOAuthProvider } from '@react-oauth/google';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
    <Provider store={store}>
      <BrowserRouter>
        <GoogleOAuthProvider clientId="746948307914-midde1q7s8btvfmr3lf80to82aut3vdi.apps.googleusercontent.com"
        onScriptLoadError={() => console.log("실패")}
        onScriptLoadSuccess={() => console.log("성공")}>
	<App />
</GoogleOAuthProvider>
      </BrowserRouter>
    </Provider>

);
reportWebVitals();
