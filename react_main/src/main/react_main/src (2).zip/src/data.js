import context from "react-bootstrap/esm/AccordionContext";

let data = [

    {
        id : 0,
        title: "White",
        content : "Born in France",
        price : 120000
    },
    {
        id : 1,
        title: "Red",
        content : "Born in France",
        price : 140000
    },
    {
        id : 2,
        title: "Blue",
        content : "Born in France",
        price : 150000
    },
]

export default data;