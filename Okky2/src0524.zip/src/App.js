import logo from './logo.svg';
import './App.css';

function App() {
  return (
    
    <div className="App">
      <div className='top-main'>
        <div className="top">
          <div>
      <img className="logo" src={require('./img/logo.png')}/>
      <img className="a" src={require('./img/Contract.png')}/>
      <button className='b'>정규직</button>
      <img className="c" src={require('./img/Talent.png')}/>
      <img className="d" src={require('./img/badgood.png')}/>
          </div>
        <div>
      <img className="e" src={require('./img/Reading.png')}/>
      <img className="f" src={require('./img/registration right.png')}/>
      <img className="g" src={require('./img/Registration.png')}/>
        </div>
      </div>  
      </div>
      
      <div className='left'>
      <div className='left-top'>내 계정</div>
      <div className='left-one'>
        <div className='propile-main'>
      <img className="propile" src={require('./img/propile.png')}/>
      <button className='propile-button'></button>
      <button className='propile-button1'>프로필</button>
      </div>
      <img className="option" src={require('./img/option.png')}/>
      <button className='option-button'></button>
      <button className='option-button1'>계정관리</button>
      </div>
      <hr className='top-hr'></hr>
      </div>

      
      {/* <div className='left filter'>
      <div className='filter'>
      <img className='img filter' src={require('./img/filter.png')}/>
      <span className='filter name'>포지션을 쉽게 찾는 스마트 필터</span>
      </div>
      <div className='left button'>
      <button className='skil'>보유기술</button>
      <button className='spack'>전체경력</button>
      <button className='posion'>포지션</button>
      <button className='work'>근무지역</button>
      </div>
    </div> */}
      <div className='footer'>
                <div className='cat'>
                    <img className='footer-cat' src={require('./img/cat.png')}/>
                </div>
                <div className='footer-main'>
                <div className='footer-bar'>
                    <button type='button'>1</button>
                </div>
                </div>
              </div>

              <div className='footer2'>
                <div className='footer-logo'>
                  <div  className='ok-logo'>
                    <img src={require('./img/okkylogo.png')}/>
                    <h2 className='ok-logoside'>All That Developer</h2>
                    </div>
                    <div>
                    <img className='facebook' src={require('./img/facebook.png')}/>
                    </div>
                    <div>
                    <img className='youtube' src={require('./img/youtube.png')}/>
                    </div>
                    <div>
                    <img className='email' src={require('./img/email.png')}/>
                    </div>

                </div>
              </div>
              <div className='footer-middle'>
                <div className='footer-btn'>
                  <div className='button-one'>
                  <button>회사소개</button>
                  </div>
                  <div className='button-two'>
                  <button>공지사항</button>
                  </div>
                  <div className='button-three'>
                  <button>FAQ</button>
                  </div>
                  <div className='button-four'>
                  <button>통합 서비스 이용약관</button>
                  </div>
                  <div className='button-five'>
                  <button>개인정보 처리방침</button>
                  </div>
                </div>
              </div>


                <div className='footer-text'>
                <div className='text-one'>
                <div>상호명:(주)오키코리아|대표명:노상범, 장기진</div>
                </div>
                <div className='text-two'>
                <div>사업자등록번호: 592-87-02037 | 통신판매업신고번호: 제 2022-서울강남-04742호 | 직업정보 제공사업 신고번호: J1200020230009</div>
                </div>
                <div className='text-three'>
                <div>주소: 서울 강남구 봉은사로 303 TGL경복빌딩 502호 (06103) | 고객센터 : jobs@okky.kr (영업시간 평일 10:00~17:00) 주말 · 공휴일 휴무</div>
                </div>
                <div className='text-four'>
                <div>© 2024 (주)오키코리아, Inc. All rights reserved.</div>
                </div>
                </div>

                <div className='last-footer'>
                <div className='sponse'>
                  <h2>SPONSORED BY</h2>
                </div>
                <div>
                <img className='iname' src={require('./img/inames.png')}/>
                </div>
                <div>
                <img className='ncloud' src={require('./img/ncloud.png')}/>
                </div>
                </div>
                

   
    </div>
    
  );
}

export default App;
