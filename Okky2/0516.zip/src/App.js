import logo from './logo.svg';
import './App.css';

function App() {
  return (
    
    <div className="App">
       <div className='category'>  
          
          <div className='category-button'> 
               
             <div className='category-button-in'>
               <div className='fixed-filter'>
                 <div className='filter-main'>
                   <div>
                   <img className='filter-main-list' src={require('./img/list.PNG')}/>
                   <span className='filter'> 포지션을 쉽게 찾는 스마트 필터</span>
                   </div>
                 </div>
                 <div className='scroll-y'>
                   
                   <div className='type'>
                     <button>포지션</button>
                     <img className='' src={require('./img/submit.PNG')}/>
                   </div>
                   <div className='position-main'>
                     <button>근무지역</button>
                     <img className='' src={require('./img/submit.PNG')}/>
                   </div>
                   <div className='skill'>
                     <button>보유기술</button>
                     <img className='' src={require('./img/submit.PNG')}/>
                   </div>
                   <div className='career'>
                     <button>전체경력</button>
                     <img className='' src={require('./img/submit.PNG')}/>
                   </div>
                  
                 
                 </div>
               </div>
               
               <div className='save'>
                 <div className='save1'>
                   <input className='save1-checkbox' type='checkbox'></input>
                   <input className='saveinput' placeholder='저장'></input>
                 </div>
                 <div className='questionimg'>
                   <img className='question' src={require('./img/question.PNG')}/>
                 </div>
                 <div className='reset'>
                   <input type='button' className='reset1'></input>
                 </div>
                 <img className='resetimg' src={require('./img/resetimg.jpg')}/>
                 <div className='reset'>
                   <input type='button' className='reset2'></input>
                 </div>
                 <div className='filtersearch'>
                   <span>필터로 검색</span>
                   <img className='magnifier' src={require('./img/Magnifier.jpg')}/>
                 </div>
                   
               </div>
             </div>
          </div>
         </div>
        <div>
      <img className="logo" src={require('./img/logo.png')}/>
      <img className="a" src={require('./img/Contract.png')}/>
      <img className="b" src={require('./img/permanent.png')}/>
      <img className="c" src={require('./img/Talent.png')}/>
      <img className="d" src={require('./img/badgood.png')}/>
<div className="top">
        </div>
        <div>
      <img className="e" src={require('./img/Reading.png')}/>
      <img className="f" src={require('./img/registration right.png')}/>
      <img className="g" src={require('./img/Registration.png')}/>
      </div>
      </div>
      {/* <div className='left filter'>
      <div className='filter'>
      <img className='img filter' src={require('./img/filter.png')}/>
      <span className='filter name'>포지션을 쉽게 찾는 스마트 필터</span>
      </div>
      <div className='left button'>
      <button className='skil'>보유기술</button>
      <button className='spack'>전체경력</button>
      <button className='posion'>포지션</button>
      <button className='work'>근무지역</button>
      </div>
    </div> */}
      

    </div>
    
  );
}

export default App;
